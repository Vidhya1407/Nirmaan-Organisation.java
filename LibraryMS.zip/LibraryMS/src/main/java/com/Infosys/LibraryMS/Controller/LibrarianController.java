package com.Infosys.LibraryMS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Infosys.LibraryMS.Entity.LibrarianEntity;
import com.Infosys.LibraryMS.Service.ILibrarianService;

@RestController
@RequestMapping("Librarians")

public class LibrarianController {
	
	@Autowired
	ILibrarianService service;
	
	@GetMapping
	public String getMethod() {
		return "This is Librarian Management System ";
	}
	
//create	
	@PostMapping ("postAdd")
	public  String postLibrarianEntity(@RequestBody LibrarianEntity LibrarianTable) {
		
		return service.addLibrarian(LibrarianTable) ;
	}
	
//read
	
	@GetMapping("readAll")                                        //to read all
	public List<LibrarianEntity> getMethod1() {
		
		return service.readAllLibrarians();
	}
	
	@GetMapping("read/{Librarian_Id}")                                 //to read by Id
	public LibrarianEntity getMethod2(@PathVariable int Librarian_Id) {
		
		return service.readLibrarian(Librarian_Id);
	}
	
//update
	
	@PutMapping("update/{Librarian_Id}")
	public String putLibrarianEntity(@PathVariable int Librarian_Id,@RequestBody LibrarianEntity LibrarianTable) {
		
		return service.updateLibrarian(Librarian_Id, LibrarianTable);
	}
	
//delete
	
	@DeleteMapping("delete/{Librarian_Id}")
	public String deleteLibrarian(@PathVariable int Librarian_Id) {
		return service.deleteLibrarian(Librarian_Id);
	}
	
	@DeleteMapping("deleteAll")
	public String deleteAllLibrarian() {
		
		return service.deleteAllLibrarians();
	}
	

}
