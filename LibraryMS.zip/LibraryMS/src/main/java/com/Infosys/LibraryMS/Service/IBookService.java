package com.Infosys.LibraryMS.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Infosys.LibraryMS.Entity.BookEntity;

@Service
public interface IBookService {
	
	public String addBook(BookEntity bookTable);           //Create
	
	public BookEntity readBook(int bookId);                 //ReadById
	public List<BookEntity> readAllBooks();                 //ReadAll
	
	public String updateBook(int bookId,BookEntity bookTable);   //updateById in Table
	
	public String deleteBook(int bookId);                   //deleteById
	public String deleteAllBooks();               //deleteAll

}
