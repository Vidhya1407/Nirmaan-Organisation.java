package com.Infosys.LibraryMS.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Infosys.LibraryMS.Entity.BookEntity;
import com.Infosys.LibraryMS.Repository.IBookRepository;

@Service
public class BookService implements IBookService {
	
	@Autowired
	IBookRepository repo;
//CREATE
	@Override
	public String addBook(BookEntity bookTable) {
		repo.save(bookTable);
		return "Successfully Added ! ";
	}
//READ
	@Override
	public BookEntity readBook(int bookId) {                       //readById
		
		return repo.findById(bookId).get();
	}

	@Override
	public List<BookEntity> readAllBooks() {                       //readAll
		
		return repo.findAll();
	}
//UPDATE
	@Override
	public String updateBook(int bookId, BookEntity bookTable) {
		
		bookTable.setBookId(bookId);
		repo.save(bookTable);
		return "Successfully Updated ! ";
	}
//DELETE
	@Override
	public String deleteBook(int bookId) {                       //deleteById
		
		return "Book Id : "+ bookId+" is deleted ! ";
	}

	@Override
	public String deleteAllBooks() {                            //deleteAll
		
		repo.deleteAll();
		return "Successfully all details deleted ! ";
	}

}
