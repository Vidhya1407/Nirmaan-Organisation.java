package com.Infosys.LibraryMS.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Librarian_Details")
public class LibrarianEntity {
	@Id                                                  //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)  //auto-increment
	private int librarian_Id;
	private String name;
	private String nameOfBook;
	private double costOfBook;
	public int getLibrarian_Id() {
		return librarian_Id;
	}
	public void setLibrarian_Id(int librarian_Id) {
		this.librarian_Id = librarian_Id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNameOfBook() {
		return nameOfBook;
	}
	public void setNameOfBook(String nameOfBook) {
		this.nameOfBook = nameOfBook;
	}
	public double getCostOfBook() {
		return costOfBook;
	}
	public void setCostOfBook(double costOfBook) {
		this.costOfBook = costOfBook;
	}
	public LibrarianEntity(int librarian_Id, String name, String nameOfBook, double costOfBook) {
		super();
		this.librarian_Id = librarian_Id;
		this.name = name;
		this.nameOfBook = nameOfBook;
		this.costOfBook = costOfBook;
	}
	public LibrarianEntity() {
		super();
	}
	
	

}
