package com.Infosys.LibraryMS.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Infosys.LibraryMS.Entity.BookEntity;
import com.Infosys.LibraryMS.Service.IBookService;

@RestController
@RequestMapping("Book")
public class BookController {
	
	@Autowired
	IBookService service;
	
	@GetMapping
	public String getMethod() {
		return "This is Book Management System ";
	}
	
//create	
	@PostMapping ("postAdd")
	public  String postBookEntity(@RequestBody BookEntity BookTable) {
		
		return service.addBook(BookTable) ;
	}
	
//read
	
	@GetMapping("readAll")                                        //to read all
	public List<BookEntity> getMethod1() {
		
		return service.readAllBooks();
	}
	
	@GetMapping("read/{bookId}")                                 //to read by Id
	public BookEntity getMethod2(@PathVariable int bookId) {
		
		return service.readBook(bookId);
	}
	
//update
	
	@PutMapping("update/{bookId}")
	public String putBookEntity(@PathVariable int bookId,@RequestBody BookEntity bookTable) {
		
		return service.updateBook(bookId, bookTable);
	}
	
//delete
	
	@DeleteMapping("delete/{bookId}")
	public String deleteBook(@PathVariable int bookId) {
		return service.deleteBook(bookId);
	}
	
	@DeleteMapping("deleteAll")
	public String deleteAllBook() {
		
		return service.deleteAllBooks();
	}
	
}
