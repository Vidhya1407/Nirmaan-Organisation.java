package com.Infosys.LibraryMS.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Infosys.LibraryMS.Entity.LibrarianEntity;
import com.Infosys.LibraryMS.Repository.ILibrarianRepository;

@Service
public class LibrarianService implements ILibrarianService{
	
	@Autowired
	ILibrarianRepository repo;

	@Override
	public String addLibrarian(LibrarianEntity librarianTable) {
		
		repo.save(librarianTable);

		return "Successfully Added !";
	}

	@Override
	public LibrarianEntity readLibrarian(int librarian_Id) {

		return repo.findById(librarian_Id).get();
	}

	@Override
	public List<LibrarianEntity> readAllLibrarians() {
		
		return repo.findAll();

	}

	@Override
	public String updateLibrarian(int librarian_Id, LibrarianEntity librarianTable) {
	    
		librarianTable.setLibrarian_Id(librarian_Id);
		repo.save(librarianTable);
		return "Successfully Updated ! ";
		}

	@Override
	public String deleteLibrarian(int librarian_Id) {
		
		return "Librarian Id : "+ librarian_Id+" is deleted ! ";

	}
		

	@Override
	public String deleteAllLibrarians() {
		
		repo.deleteAll();
		return "Successfully all details deleted ! ";
	
	}

}
