package com.Infosys.LibraryMS.Service;

import java.util.List;

import com.Infosys.LibraryMS.Entity.LibrarianEntity;


public interface ILibrarianService {
	//crud
	
    public String addLibrarian(LibrarianEntity librarianTable);                           //Create
	
	public LibrarianEntity readLibrarian(int librarian_Id);                               //ReadById
	public List<LibrarianEntity> readAllLibrarians();                                     //ReadAll
	
	public String updateLibrarian(int librarian_Id,LibrarianEntity librarianTable);      //updateById in Table
	
	public String deleteLibrarian(int librarian_Id);                                     //deleteById
	public String deleteAllLibrarians();                                                 //deleteAll


}
