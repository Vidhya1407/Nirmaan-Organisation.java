package com.Infosys.LibraryMS.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Book_Details")
public class BookEntity {
	
	@Id                                                  //primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)  //auto-increment
	private int bookId;
	private String bookNameString;
	private String authorName;
	private double bookCost;
	
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookNameString() {
		return bookNameString;
	}
	public void setBookNameString(String bookNameString) {
		this.bookNameString = bookNameString;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public double getBookCost() {
		return bookCost;
	}
	public void setBookCost(double bookCost) {
		this.bookCost = bookCost;
	}
	public BookEntity(int bookId, String bookNameString, String authorName, double bookCost) {
		super();
		this.bookId = bookId;
		this.bookNameString = bookNameString;
		this.authorName = authorName;
		this.bookCost = bookCost;
	}
	public BookEntity() {
		super();
	}
	
	

}
